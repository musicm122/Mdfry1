<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="PSF_A4_Interior" tilewidth="32" tileheight="32" tilecount="1104" columns="23">
 <image source="PSF_A4_Interior.png" width="736" height="1536"/>
</tileset>
