<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="TileD_PHC_Interior-Delapidated" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="TileD_PHC_Interior-Delapidated.png" width="512" height="512"/>
</tileset>
