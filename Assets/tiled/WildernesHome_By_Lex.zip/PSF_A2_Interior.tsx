<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="PSF_A2_Interior" tilewidth="32" tileheight="32" tilecount="480" columns="24">
 <image source="PSF_A2_Interior.png" width="768" height="640"/>
</tileset>
