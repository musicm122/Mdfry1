<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="PSF_E_Interior_Extras" tilewidth="32" tileheight="32" tilecount="256" columns="16">
 <image source="PSF_E_Interior_Extras.png" trans="ff00ff" width="512" height="512"/>
</tileset>
