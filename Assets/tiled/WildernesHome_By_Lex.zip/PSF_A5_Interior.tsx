<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="PSF_A5_Interior" tilewidth="32" tileheight="32" tilecount="128" columns="8">
 <image source="PSF_A5_Interior.png" width="256" height="512"/>
</tileset>
